from django.contrib import admin

from .models import EventRequest

# Register your models here.
models_list = [EventRequest]
admin.site.register(models_list)
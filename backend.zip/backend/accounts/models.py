from django.contrib.auth.models import User


from django.db import models
class EventRequest(models.Model):
    STATUS_CHOICES = (
        ('pending', 'En cours de traitement'),
        ('accepted', 'Accepté'),
        ('rejected', 'Rejeté'),
    )
    title = models.CharField(max_length=100)
    description = models.TextField()
    organizer = models.ForeignKey(User, on_delete=models.CASCADE)
    committee = models.CharField(max_length=100)
    event_type = models.CharField(max_length=50)
    start_date = models.DateField()
    end_date = models.DateField()
    needs = models.TextField()
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default='pending')